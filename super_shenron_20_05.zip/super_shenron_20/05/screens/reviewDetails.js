import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  CheckBox,
  ScrollView,
  DrawerLayoutAndroid,
} from 'react-native';
import {globalStyles, images } from '../styles/global'; 

export default function ReviewDetails({navigation}) {
  const pressHandler = () => {
    navigation.goBack();
  }; 
  const key = navigation.getParam('key');

    return(
      <View >
      <Image style={styles.cardImage} source={images.key[key]} />
      <View>
      <Text style={styles.cardValue}>Name:     <Text style={styles.cardData}>{navigation.getParam('name')}</Text></Text>
      <Text style={styles.cardValue}>Species:     <Text style={styles.cardData}>{navigation.getParam('species')}</Text></Text>
      <Text style={styles.cardValue}>Planet of Origin:     <Text style={styles.cardData}>{navigation.getParam('planetoforigin')}</Text></Text>
      <TouchableOpacity onPress={pressHandler} style={styles.button}>
      <Text style={{ fontSize: 20, fontWeight: 'bold'}}>     HOME</Text>
      </TouchableOpacity>
      </View>
      </View>


    )
}

const styles = StyleSheet.create({
  cardImage: {
    marginTop: 10,
    marginBottom: 20,
    marginLeft: '3%',
    borderColor: 'black',
    borderWidth: 3,
    elevation: 10,
    width: '94%',
    height: 200,
  },
  button: {
    backgroundColor: 'lightgreen',
    marginTop:200,
    marginLeft: '35%',
    width:'30%',
    height:30,
    borderRadius: 10,
  },
  cardValue: {
    marginLeft:'6%',
    fontSize: 20,
    fontWeight: 'bold',
    color: 'brown',
  },
  cardData: {
    fontSize: 20,
    color: 'coral',
  },
});