import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  CheckBox,
  ScrollView,
  DrawerLayoutAndroid,
} from 'react-native';

import Navigator from './routes/homeStack';

export default function App() {
  return (
    <Navigator />
  );
}


