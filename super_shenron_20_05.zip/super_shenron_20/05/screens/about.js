import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  CheckBox,
  ScrollView,
  DrawerLayoutAndroid,
} from 'react-native';

export default function About() {
    return(
      <View>
      <Text>About Screen</Text>
      </View>
    )
}

