import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  CheckBox,
  ScrollView,
  DrawerLayoutAndroid,
} from 'react-native';
import Card from '../shared/card';
import {globalStyles, images, favImages } from '../styles/global'; 

export default function Home({ navigation }) {
  const [review, setReview] = useState ([
    {name: 'Super Shenron 1', key: '1', species: 'dragon1', planetoforigin: 'earth1', likes: '0' },
    {name: 'Super Shenron 2', key: '2', species: 'dragon2', planetoforigin: 'earth2', likes: '0' },
    {name: 'Super Shenron 3', key: '3', species: 'dragon3', planetoforigin: 'earth3', likes: '0' },
    {name: 'Super Shenron 4', key: '4', species: 'dragon4', planetoforigin: 'earth4', likes: '0' },
    {name: 'Super Shenron 5', key: '5', species: 'dragon5', planetoforigin: 'earth5', likes: '0' },
  ]);

  const [count, setCount] = useState(0);

  const onPressLike = () => {
    setCount(count + 1);
  };
  const onPressDislike = () => {
    setCount(count - 1);
  };

  return (
    <View style={styles.container}>
    <FlatList
      data={review}
      renderItem={({item}) => (
      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('ReviewDetails', item)}>
        <View>
          <Image style={styles.cardImage} source={images.key[item.key]} />
          <Text style={styles.cardText}>{item.name}</Text>
        </View>

        <View style={{ flexDirection: 'row' }}>
          <TouchableOpacity onPress={onPressLike} style={styles.like}>
            <Image
              style={styles.likeImage}
              source={require('../assets/like.jpg')}
            />
          </TouchableOpacity>
          <Text style={styles.likeOutput}>{count !== 0 ? count : null}</Text>
          <TouchableOpacity onPress={onPressDislike} style={styles.dislike}>
            <Image style={styles.likeImage}
            source={require('../assets/dislike.jpg')}
            />
          </TouchableOpacity>
          <Text>         </Text>
          <TouchableOpacity style={styles.dislike}>
          <Image style={styles.favImage} source={require('../assets/favourite_no.jpg')} />
          </TouchableOpacity > 
          <Text style={styles.compare}>        Compare</Text>
          <CheckBox style={styles.checkBox} />
        </View>
      </TouchableOpacity>
      )}
    />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
    backgroundColor: 'grey',
  },
  card: {
    backgroundColor: 'ivory',
    marginBottom: 10,
    marginLeft: '2%',
    width: '96%',
    borderWidth: 2,
    borderColor: 'black',
    shadowOffset: {
      width: 3,
      height: 3,
    },
  },
  like: {
    marginBottom: 2,
    marginLeft: 5,
    width: '10%',
  },
  dislike: {
    marginBottom: 2,
    width: '10%',
  },
  favImage: {
    height:30,
    width:'100%' ,
  },
  cardImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
  },
  checkBox: {
    marginTop: 4,
  },
  likeImage: {
    width: '100%',
    height: 30,
  },
  likeOutput: {
    color: 'blue',
    fontSize: 18,
    marginTop: 5,
    marginLeft: 3,
    width: '8%',
  },
  compare: {
    color: 'lightcoral',
    fontSize: 20,
    marginTop: 3,
    width:'40%',
  },
  cardText: {
    color: 'green',
    textAlign: 'center',
    padding: 2,
    fontSize: 24,
  },
});

