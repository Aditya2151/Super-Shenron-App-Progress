import { useState } from 'react';

export const images = {
  key: {
    '1': require('../assets/1.jpg'),
    '2': require('../assets/2.jpg'),
    '3': require('../assets/3.jpg'),
    '4': require('../assets/4.jpg'),
    '5': require('../assets/5.jpg'),
  }
};
export const favImages = {
    '1': require('../assets/favourite_yes.jpg'),
    '0': require('../assets/favourite_no.jpg'),
}
