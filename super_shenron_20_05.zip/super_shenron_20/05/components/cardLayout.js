import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  CheckBox,
  ScrollView,
  DrawerLayoutAndroid,
} from 'react-native';

export default function CardLayout() {

  const [card, setCard] = useState ([
    {name: 'Super Shenron 1', key: '1' },
    {name: 'Super Shenron 2', key: '2' },
    {name: 'Super Shenron 3', key: '3' },
    {name: 'Super Shenron 4', key: '4' },
    {name: 'Super Shenron 5', key: '5',},
    {name: 'Super Shenron 6', key: '6' },
    {name: 'Super Shenron 7', key: '7' },
    {name: 'Super Shenron 8', key: '8' },
    {name: 'Super Shenron 9', key: '9' },
    {name: 'Super Shenron 10', key: '10' },
    {name: 'Super Shenron 11', key: '11' },
  ]);

  return (
    <TouchableOpacity style={styles.card}>
      <View>
        <Image style={styles.cardImage} source={require('./assets/2.jpg')} />
        <Text style={styles.cardText}>Super Shenron</Text>
      </View>

      <View style={{ flexDirection: 'row' }}>
        <TouchableOpacity style={styles.like}>
          <Image
            style={styles.likeImage}
            source={require('./assets/like.jpg')}
          />
        </TouchableOpacity>
        <Text style={styles.likeOutput}>10</Text>
        <TouchableOpacity style={styles.dislike}>
          <Image
            style={styles.likeImage}
            source={require('./assets/dislike.jpg')}
          />
        </TouchableOpacity>
        <Text style={styles.compare}>                 Compare</Text>
        <CheckBox style={styles.checkBox} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'ivory',
    marginBottom: 10,
    marginLeft: '2%',
    width: '96%',
    borderWidth: 2,
    borderColor: 'black',
    shadowOffset: {
      width: 3,
      height: 3,
    },
  },
  like: {
    marginBottom: 2,
    marginLeft: 5,
    width: '10%',
  },
  dislike: {
    marginBottom: 2,
    width: '10%',
  },
  cardImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
  },
  checkBox: {
    marginTop: 3,
  },
  likeImage: {
    width: '100%',
    height: 30,
  },
  likeOutput: {
    color: 'blue',
    fontSize: 18,
    marginTop: 5,
    marginLeft: 3,
    width: '10%',
  },
  compare: {
    color: 'lightcoral',
    fontSize: 20,
    marginTop: 3,
    width: '50%',
  },
  cardText: {
    color: 'green',
    textAlign: 'center',
    padding: 2,
    fontSize: 24,
  },
});

